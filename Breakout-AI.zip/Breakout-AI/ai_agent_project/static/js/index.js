document.addEventListener('DOMContentLoaded', () => {
    // Add smooth fade-in for button click events
    const buttons = document.querySelectorAll('.btn');
    buttons.forEach(button => {
        button.addEventListener('click', (e) => {
            e.target.classList.add('clicked');
            setTimeout(() => {
                e.target.classList.remove('clicked');
            }, 300);
        });
    });
});
