import openai

def query_llm(entity, search_results, query_template):
    openai.api_key = "YOUR_OPENAI_API_KEY"
    context = "\n".join([result["snippet"] for result in search_results if "snippet" in result])
    prompt = query_template.format(entity=entity) + f"\nContext:\n{context}\nExtract relevant information."

    try:
        response = openai.Completion.create(
            engine="text-davinci-003",
            prompt=prompt,
            max_tokens=150
        )
        return response.choices[0].text.strip()
    except Exception as e:
        return str(e)
