import requests

def perform_web_search(entity, query_template):
    api_key = "YOUR_SERPAPI_KEY"
    query = query_template.format(entity=entity)
    url = f"https://serpapi.com/search.json?q={query}&api_key={api_key}"
    response = requests.get(url)
    if response.status_code == 200:
        return response.json().get("organic_results", [])
    return {"error": "Search failed"}
