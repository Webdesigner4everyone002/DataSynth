import pandas as pd

def save_results_to_csv(results, file_path="results.csv"):
    df = pd.DataFrame(results)
    df.to_csv(file_path, index=False)
