from flask import Flask, render_template, request, jsonify, send_file
import pandas as pd
from utils.google_sheets import connect_google_sheet
from utils.web_search import perform_web_search
from utils.llm_processing import query_llm
from utils.file_handling import save_results_to_csv

app = Flask(__name__)

# Global Variables
uploaded_data = None
results = []

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/upload", methods=["POST"])
def upload_file():
    global uploaded_data
    if "file" in request.files:
        file = request.files["file"]
        uploaded_data = pd.read_csv(file)
        return jsonify({"columns": list(uploaded_data.columns)})
    return jsonify({"error": "No file uploaded"}), 400

@app.route("/google-sheet", methods=["POST"])
def upload_google_sheet():
    global uploaded_data
    data = request.json
    sheet_url = data.get("sheet_url")
    if not sheet_url:
        return jsonify({"error": "No Google Sheet URL provided"}), 400
    uploaded_data = connect_google_sheet(sheet_url)
    return jsonify({"columns": list(uploaded_data.columns)})

@app.route("/process", methods=["POST"])
def process_data():
    global uploaded_data, results
    if uploaded_data is None:
        return jsonify({"error": "No data to process"}), 400

    data = request.json
    column = data.get("column")
    query_template = data.get("query")
    if column not in uploaded_data.columns:
        return jsonify({"error": "Invalid column name"}), 400

    entities = uploaded_data[column].dropna().unique()
    results = []

    for entity in entities:
        search_results = perform_web_search(entity, query_template)
        parsed_result = query_llm(entity, search_results, query_template)
        results.append({"entity": entity, "result": parsed_result})

    save_results_to_csv(results)
    return jsonify(results)

@app.route("/download", methods=["GET"])
def download_results():
    return send_file("results.csv", as_attachment=True)

if __name__ == "__main__":
    app.run(debug=True)
